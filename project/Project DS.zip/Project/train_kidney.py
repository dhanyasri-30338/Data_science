import pandas as pd
import pickle

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

df = pd.read_csv("datasets/kidney.csv")

df = df.fillna(df.mode().iloc[0])

target = "classification"

X = df.drop(target, axis=1)
y = df[target]

X = pd.get_dummies(X)

pickle.dump(
X.columns.tolist(),
open("models/kidney_columns.pkl", "wb")
)

X_train, X_test, y_train, y_test = train_test_split(
X,
y,
test_size=0.2,
random_state=42
)

model = RandomForestClassifier(
n_estimators=100,
random_state=42
)

model.fit(X_train, y_train)

pred = model.predict(X_test)

print(
"Kidney Accuracy:",
accuracy_score(y_test, pred)
)

pickle.dump(
model,
open("models/kidney_model.pkl", "wb")
)

print("Kidney Model Saved")
print("Kidney Columns Saved")
