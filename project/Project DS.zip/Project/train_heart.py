import pandas as pd
import pickle

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Load dataset
df = pd.read_csv("datasets/heart.csv")

# Convert text columns to numbers
for col in df.columns:
    if df[col].dtype == "object":
        df[col] = pd.factorize(df[col])[0]

# Find target column
if "target" in df.columns:
    target = "target"
elif "HeartDisease" in df.columns:
    target = "HeartDisease"
elif "num" in df.columns:
    target = "num"
else:
    target = df.columns[-1]

# Features and target
X = df.drop(target, axis=1)
y = df[target]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Model
model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

model.fit(X_train, y_train)

pred = model.predict(X_test)

print(
    "Heart Accuracy:",
    accuracy_score(y_test, pred)
)

# Save model
pickle.dump(
    model,
    open(
        "models/heart_model.pkl",
        "wb"
    )
)

print("Heart Model Saved")