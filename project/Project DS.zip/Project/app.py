from flask import Flask, render_template, request
import pickle
import pandas as pd

app = Flask(__name__)

# Load Models
diabetes_model = pickle.load(
    open("models/diabetes_model.pkl", "rb")
)

heart_model = pickle.load(
    open("models/heart_model.pkl", "rb")
)

kidney_model = pickle.load(
    open("models/kidney_model.pkl", "rb")
)

kidney_columns = pickle.load(
    open("models/kidney_columns.pkl", "rb")
)


# ======================
# HOME
# ======================

@app.route("/")
def home():
    return render_template("index.html")


# ======================
# DIABETES
# ======================

@app.route("/diabetes")
def diabetes():
    return render_template("diabetes.html")


@app.route("/predict_diabetes", methods=["POST"])
def predict_diabetes():

    data = [
        float(request.form["pregnancies"]),
        float(request.form["glucose"]),
        float(request.form["bloodpressure"]),
        float(request.form["skinthickness"]),
        float(request.form["insulin"]),
        float(request.form["bmi"]),
        float(request.form["dpf"]),
        float(request.form["age"])
    ]

    prediction = diabetes_model.predict([data])[0]

    probability = diabetes_model.predict_proba([data])[0]

    confidence = round(
        max(probability) * 100,
        2
    )

    if prediction == 1:

        result = "HIGH RISK"

        recommendation = """
        Consult a healthcare professional,
        monitor blood glucose levels,
        maintain healthy diet and exercise.
        """

    else:

        result = "LOW RISK"

        recommendation = """
        Continue healthy lifestyle habits
        and regular medical checkups.
        """

    return render_template(
        "result.html",
        disease="Diabetes",
        result=result,
        confidence=confidence,
        recommendation=recommendation
    )


# ======================
# HEART
# ======================

@app.route("/heart")
def heart():
    return render_template("heart.html")


@app.route("/predict_heart", methods=["POST"])
def predict_heart():

    data = [
        float(request.form["id"]),
        float(request.form["age"]),
        float(request.form["sex"]),
        float(request.form["dataset"]),
        float(request.form["cp"]),
        float(request.form["trestbps"]),
        float(request.form["chol"]),
        float(request.form["fbs"]),
        float(request.form["restecg"]),
        float(request.form["thalch"]),
        float(request.form["exang"]),
        float(request.form["oldpeak"]),
        float(request.form["slope"]),
        float(request.form["ca"]),
        float(request.form["thal"])
    ]

    prediction = heart_model.predict([data])[0]

    probability = heart_model.predict_proba([data])[0]

    confidence = round(
        max(probability) * 100,
        2
    )

    if prediction > 0:

        result = "HEART DISEASE DETECTED"

        recommendation = """
        Consult a cardiologist immediately
        and undergo further evaluation.
        """

    else:

        result = "NO HEART DISEASE DETECTED"

        recommendation = """
        Continue healthy lifestyle habits
        and routine cardiovascular checkups.
        """

    return render_template(
        "result.html",
        disease="Heart Disease",
        result=result,
        confidence=confidence,
        recommendation=recommendation
    )


# ======================
# KIDNEY
# ======================

@app.route("/kidney")
def kidney():
    return render_template("kidney.html")


@app.route("/predict_kidney", methods=["POST"])
def predict_kidney():

    sample = {
        "age": request.form["age"],
        "bp": request.form["bp"],
        "sg": request.form["sg"],
        "al": request.form["al"],
        "su": request.form["su"],
        "bgr": request.form["bgr"],
        "bu": request.form["bu"],
        "sc": request.form["sc"],
        "sod": request.form["sod"],
        "pot": request.form["pot"],
        "hemo": request.form["hemo"]
    }

    df = pd.DataFrame([sample])

    df = pd.get_dummies(df)

    df = df.reindex(
        columns=kidney_columns,
        fill_value=0
    )

    prediction = kidney_model.predict(df)[0]

    probability = kidney_model.predict_proba(df)[0]

    confidence = round(
        max(probability) * 100,
        2
    )

    if str(prediction).lower() in ["ckd", "1"]:

        result = "KIDNEY DISEASE DETECTED"

        recommendation = """
        Consult a nephrologist,
        maintain hydration and
        undergo further kidney evaluation.
        """

    else:

        result = "NO KIDNEY DISEASE DETECTED"

        recommendation = """
        Maintain healthy kidney function
        through proper hydration and
        regular health screenings.
        """

    return render_template(
        "result.html",
        disease="Kidney Disease",
        result=result,
        confidence=confidence,
        recommendation=recommendation
    )


if __name__ == "__main__":
    app.run(debug=True)